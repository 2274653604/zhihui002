create definer = root@localhost view view_work_area as
select `w`.`w_id`        AS `w_id`,
       `w`.`w_name`      AS `w_name`,
       count(`s`.`s_id`) AS `w_num`,
       `s`.`s_name`      AS `s_name`,
       `w`.`w_status`    AS `w_status`
from (`111`.`work_area` `w` join `111`.`staff` `s` on ((`w`.`w_id` = `s`.`w_id`)))
group by `w`.`w_id`;

