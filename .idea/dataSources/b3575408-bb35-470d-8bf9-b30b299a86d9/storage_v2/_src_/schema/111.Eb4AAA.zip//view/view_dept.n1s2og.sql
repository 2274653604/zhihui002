create definer = root@localhost view view_dept as
select `d`.`d_id` AS `d_id`, `d`.`d_name` AS `d_name`, count(`s`.`s_id`) AS `d_num`, `s`.`s_name` AS `s_name`
from (`111`.`dept` `d` join `111`.`staff` `s` on ((`d`.`d_id` = `s`.`d_id`)))
group by `d`.`d_id`;

