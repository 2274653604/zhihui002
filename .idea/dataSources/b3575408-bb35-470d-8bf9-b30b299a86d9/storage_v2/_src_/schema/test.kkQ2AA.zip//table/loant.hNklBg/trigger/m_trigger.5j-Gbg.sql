create definer = root@localhost trigger m_trigger
    after insert
    on loant
    for each row
begin
    update bankt set bankt.bamount=NEW.lamount+bankt.bamount where bankt.bno=NEW.bno;
    update let set let.eamount=NEW.lamount+let.eamount where let.eno=NEW.eno;
end;

