create
    definer = root@localhost procedure pro_2(IN v_sno char(10), OUT v_cnt int, OUT v_coursestr varchar(5000))
begin
    declare done int default 1;
    declare str varchar(5000) default '';
    declare u_cursor cursor for
    select c.cname
    from course c,sc
    where c.cno=sc.cno and sc.sno=v_sno
    order by c.semester,c.cno;
    declare continue handler for not found set done=0;
    open u_cursor;
    set v_cnt=0;
    set v_coursestr='';
    while done do
        fetch u_cursor into str;
        set v_cnt=v_cnt+1;
        set v_coursestr=concat(v_coursestr,';',str);
    end while;
    close u_cursor;
end;

