create definer = root@localhost trigger update_dept_num
    after update
    on staff
    for each row
BEGIN
    UPDATE dept SET d_num = (SELECT COUNT(*) FROM staff WHERE d_id = NEW.d_id) WHERE d_id = NEW.d_id;
END;

