create definer = root@localhost trigger delete_dept_num
    after delete
    on staff
    for each row
BEGIN
    UPDATE dept SET d_num = (SELECT COUNT(*) FROM staff WHERE d_id = OLD.d_id) WHERE d_id = OLD.d_id;
END;

