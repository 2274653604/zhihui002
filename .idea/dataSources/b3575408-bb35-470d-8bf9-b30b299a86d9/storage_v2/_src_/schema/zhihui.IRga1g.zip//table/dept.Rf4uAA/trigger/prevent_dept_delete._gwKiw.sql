create definer = root@localhost trigger prevent_dept_delete
    before delete
    on dept
    for each row
BEGIN
    DECLARE num_rows INT;
    SELECT COUNT(*) INTO num_rows FROM staff WHERE d_id = OLD.d_id;
    IF num_rows > 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cannot delete department with associated staff records';
    END IF;
END;

