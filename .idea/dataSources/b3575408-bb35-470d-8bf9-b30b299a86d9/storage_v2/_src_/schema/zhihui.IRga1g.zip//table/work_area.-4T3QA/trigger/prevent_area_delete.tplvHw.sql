create definer = root@localhost trigger prevent_area_delete
    before delete
    on work_area
    for each row
BEGIN
    DECLARE num_rows INT;
    SELECT COUNT(*) INTO num_rows FROM staff WHERE w_id = OLD.w_id;
    IF num_rows > 0 THEN
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cannot delete workarea with associated staff records';
    END IF;
END;

