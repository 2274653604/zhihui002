create definer = root@localhost view view_staff as
select `s`.`s_id`     AS `s_id`,
       `s`.`s_name`   AS `s_name`,
       `s`.`s_sex`    AS `s_sex`,
       `s`.`s_age`    AS `s_age`,
       `d`.`d_name`   AS `d_name`,
       `w`.`w_name`   AS `w_name`,
       `s`.`s_status` AS `s_status`
from ((`zhihui`.`staff` `s` join `zhihui`.`dept` `d` on ((`s`.`d_id` = `d`.`d_id`))) left join `zhihui`.`work_area` `w`
      on ((`s`.`w_id` = `w`.`w_id`)));

