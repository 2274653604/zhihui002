create definer = root@localhost trigger insert_area_num
    after insert
    on staff
    for each row
BEGIN
    UPDATE work_area SET w_num = (SELECT COUNT(*) FROM staff WHERE w_id = NEW.w_id) WHERE w_id = NEW.w_id;
END;

