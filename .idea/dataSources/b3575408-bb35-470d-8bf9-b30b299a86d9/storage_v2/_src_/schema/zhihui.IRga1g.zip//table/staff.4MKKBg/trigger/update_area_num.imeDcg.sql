create definer = root@localhost trigger update_area_num
    after update
    on staff
    for each row
BEGIN
    UPDATE work_area SET w_num = (SELECT COUNT(*) FROM staff WHERE w_id = NEW.w_id) WHERE w_id = NEW.w_id;
END;

