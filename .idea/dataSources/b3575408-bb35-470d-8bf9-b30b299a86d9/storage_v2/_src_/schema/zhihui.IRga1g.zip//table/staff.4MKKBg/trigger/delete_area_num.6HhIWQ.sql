create definer = root@localhost trigger delete_area_num
    after delete
    on staff
    for each row
BEGIN
    UPDATE work_area SET w_num = (SELECT COUNT(*) FROM staff WHERE w_id = OLD.w_id) WHERE w_id = OLD.w_id;
END;

