create definer = root@localhost trigger update_dept_s_adminname
    after update
    on staff
    for each row
BEGIN
    IF OLD.s_name != NEW.s_name THEN
        UPDATE dept SET s_adminname = NEW.s_name WHERE s_admin_id = NEW.s_id;
    END IF;
END;

