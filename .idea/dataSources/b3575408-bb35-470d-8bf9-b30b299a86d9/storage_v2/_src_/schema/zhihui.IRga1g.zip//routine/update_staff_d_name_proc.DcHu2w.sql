create
    definer = root@localhost procedure update_staff_d_name_proc(IN d_id_param int, IN new_d_name_param varchar(255))
BEGIN
    UPDATE staff SET d_name = new_d_name_param WHERE d_id = d_id_param;
END;

